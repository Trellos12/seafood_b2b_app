<?php
/**
 * Plugin Name: Fish Password API
 * Plugin URI: https://github.com/Trellos12/fish-password-api
 * Description: Custom JWT endpoint to change passwords for authenticated users.
 * Version: 1.0.0
 * Author: GPT Dev
 * Author URI: https://github.com/Trellos12
 * License: GPL2
 * GitHub Plugin URI: https://github.com/Trellos12/fish-password-api
 * Primary Branch: main
 */

add_action('rest_api_init', function () {
    register_rest_route('fish/v1', '/change-password', [
        'methods' => 'POST',
        'callback' => 'fish_change_password',
        'permission_callback' => function () {
            return is_user_logged_in();
        }
    ]);
});

function fish_change_password(WP_REST_Request $request) {
    $user = wp_get_current_user();
    $new_password = $request->get_param('password');

    if (!$user || empty($new_password)) {
        return new WP_Error('invalid_request', 'Missing or invalid password', ['status' => 400]);
    }

    wp_set_password($new_password, $user->ID);

    return new WP_REST_Response(['message' => 'Password updated successfully'], 200);
}
