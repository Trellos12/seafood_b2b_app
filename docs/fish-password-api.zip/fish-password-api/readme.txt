=== Fish Password API ===
Contributors: trellos12
Tags: password, JWT, REST API
Requires at least: 5.0
Tested up to: 6.4
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Custom WordPress plugin for authenticated users to change their password using JWT and REST API.
