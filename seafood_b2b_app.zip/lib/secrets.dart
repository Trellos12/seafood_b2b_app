/// 🔐 WooCommerce API credentials + base URL
class Secrets {
  /// 🌐 URL WooCommerce (без `/wp-json`)
  static const baseUrl =
      'https://galileo.fish-star.com.gr'; // ⬅️ замени на свой

  /// 🔑 WooCommerce REST API keys
  static const consumerKey =
      'ck_f487f9534adb1afe7dfb312266ea64dd3942a13b'; // ⬅️ вставь свои ключи
  static const consumerSecret =
      'cs_80557625f02f3f6c91ef0afceb855f74c2b2da3a'; // ⬅️ вставь свои ключи
}
