class AppConfig {
  /// 👇 Сюда вставляй свой текущий поддомен (или основной домен в будущем)
  static const String baseUrl = 'https://galileo.fish-star.com.gr/';

  /// 🔐 WooCommerce REST API ключи
  static const String consumerKey =
      'ck_f487f9534adb1afe7dfb312266ea64dd3942a13b';
  static const String consumerSecret =
      'cs_80557625f02f3f6c91ef0afceb855f74c2b2da3a';
}
