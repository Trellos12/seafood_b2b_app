package com.example.seafood_b2b_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
